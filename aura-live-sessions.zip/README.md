# ◆ AURA — Live Camera & Microphone Sessions

A premium, privacy-first web application for hosting **live, one-to-one camera &
microphone sessions** over WebRTC. A host generates a unique, cryptographically
random link; the participant opens it, explicitly grants camera & microphone
access through the browser's **native permission system**, and streams to the
host in real time. **Nothing is ever recorded.**

> Crafted by **Suhan**

---

## ✨ Features

### For the host (creator)
- One-click session creation with a **crypto-random** session ID and secure link
- Live participant status panel — *Waiting for participant → Participant
  connected → Camera connected → Microphone connected*
- **Start / Stop** session controls with a live **session timer**
- Live camera preview, pulsing **microphone activity meter**, live connection
  indicator, copy-link button, end-session button
- Refresh-safe: the host can reload and re-take control with a stored token

### For the participant
- Clear permission screen: *"This session is requesting access to your camera
  and microphone"*
- Separate, obvious **Allow Camera & Microphone** and **Decline** actions
- Uses only the **browser's native permission prompt** — never bypassed,
  hidden, or auto-granted
- A **highly visible LIVE indicator** (pulsing red bar + camera/mic chips)
  whenever they are broadcasting
- One-tap **Stop Sharing** that instantly terminates the stream
- Graceful handling of permission denial, missing/busy devices, disconnects,
  refreshes, network changes, and session expiry

### Privacy & security
- **Consent-first**: the host can *never* silently activate a participant's
  camera or microphone — media starts only after the participant clicks Allow
  **and** approves the browser prompt
- **No recording**: media is relayed peer-to-peer only; nothing is stored
- **WebRTC P2P**: audio/video flows directly between peers (the server never
  sees it)
- **Secure signaling** with per-role authorization and short-lived,
  HMAC-signed join tickets
- Server-side session validation on every message, rate limiting, and
  auto-expiry of inactive links

---

## 🚀 Quick start

```bash
cd live-session
npm install
npm start          # or: node server/index.js
```

Open **http://localhost:3000** — that's the host dashboard.

1. Click **Create live session** → copy the invite link.
2. Open the link in another browser / tab / device → that's the participant.
3. Participant clicks **Allow Camera & Microphone** and approves the browser
   prompt.
4. Host clicks **Start session** → the live feed appears with status badges,
   mic meter, and timer.

> **Requirements:** Node.js ≥ 16 (tested on Node 20). Only two runtime
> dependencies: `express` and `ws`.

---

## 🧭 How it works

```
┌────────────┐   HTTPS + WSS (signaling only)   ┌──────────────┐
│   HOST     │ ◄──────────────────────────────► │   SERVER     │
│  (creator) │          /signal (WebSocket)     │  (Node.js)   │
└─────┬──────┘                                  └──────┬───────┘
      │                                                │
      │        WebRTC (SRTP audio/video, P2P)          │
      └───────────────────────┬────────────────────────┘
                              │
                        ┌─────▼──────┐   HTTPS + WSS   ┌──────────────┐
                        │   MEDIA    │ ◄──────────────► │ PARTICIPANT  │
                        │  (direct)  │     /signal      │   (guest)    │
                        └────────────┘                  └──────────────┘
```

### Session lifecycle

| Phase | Host sees | Participant sees |
| --- | --- | --- |
| Created | *Waiting for participant* | — |
| Participant opens link | *Participant connected* | Permission screen |
| Participant allows + browser grants | *Camera/Microphone connected* | Local preview + **LIVE** indicator |
| Host starts | Live feed, timer running | Streaming to host |
| Host stops / participant stops sharing | Back to standby | Consent screen (sharing stopped) |
| Expired / ended | Session closed | *Session ended* screen |

### Signaling protocol (all messages validated server-side)

| Direction | Message | Meaning |
| --- | --- | --- |
| server → client | `hello` / `state` | Full session snapshot |
| server → client | `peer-joined` / `peer-left` | Peer presence |
| server → client | `session-started` / `session-stopped` | Live phase changes |
| server → client | `media-ready` / `media-stopped` / `declined` | Consent state |
| both → peer | `signal` (`offer` / `answer` / `ice`) | WebRTC SDP/ICE relay |
| creator → server | `start-session` / `stop-session` / `end-session` | Host controls |
| participant → server | `media-ready` / `media-stopped` / `declined` | Consent state |

Authorization:
- **Creator** connects with the session's `creatorToken` (constant-time compare).
- **Participant** connects with a **60-second HMAC-signed ticket** issued by
  `POST /api/sessions/:id/join` (validated with `crypto.timingSafeEqual`).
- Roles are enforced per message — a participant **cannot** start/end a
  session, and a creator **cannot** claim a participant granted access.

WebSocket close codes: `4001` expired · `4002` ended · `4003` unauthorized ·
`4004` rate-limited · `4005` room full · `4006` replaced by newer connection.

---

## 🗂 Project structure

```
live-session/
├── server/
│   ├── index.js          # Express app, REST API, WS upgrade, lifecycle
│   ├── config.js         # All tunables via env vars
│   ├── sessionStore.js   # In-memory sessions + auto-expiry sweeper
│   ├── signaling.js      # WebSocket signaling + role enforcement
│   ├── tokens.js         # CSPRNG ids, HMAC tickets, timing-safe compare
│   └── rateLimit.js      # Sliding-window rate limiter (per IP)
├── public/
│   ├── index.html        # Host dashboard
│   ├── join.html         # Participant page  (/s/:id)
│   ├── css/styles.css    # Dark glassmorphism theme
│   └── js/
│       ├── shared.js     # helpers (toasts, clock, copy, ws url)
│       ├── webrtc.js     # RTCPeerConnection + mic meter helpers
│       ├── creator.js    # Host controller
│       └── participant.js# Participant controller (consent-first)
├── package.json
└── README.md
```

---

## 🔧 Configuration

All settings are optional and read from the environment (see `.env.example`):

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `3000` | HTTP/WSS port |
| `HOST` | `0.0.0.0` | Bind address |
| `PUBLIC_BASE_URL` | *(derived)* | Base URL used to build share links |
| `SIGNAL_SECRET` | *(random per boot)* | HMAC secret for join tickets — **set in production** |
| `SESSION_MAX_AGE_MS` | `14400000` (4h) | Hard lifetime of a session link |
| `SESSION_IDLE_MS` | `600000` (10m) | Inactivity before a link auto-expires |
| `TICKET_TTL_MS` | `60000` (60s) | Lifetime of participant join tickets |
| `ENABLE_CSP` | `false` | Enable strict Content-Security-Policy |
| `ENABLE_FRAME_DENY` | `false` | Send `X-Frame-Options: DENY` |

```bash
SIGNAL_SECRET=$(openssl rand -hex 32) npm start
```

---

## ☁️ Production deployment

1. **HTTPS + WSS are required** — `getUserMedia` only works in secure
   contexts. Terminate TLS at a reverse proxy and forward WebSockets:

   ```nginx
   # nginx example
   location / {
     proxy_pass http://127.0.0.1:3000;
     proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
     proxy_set_header X-Forwarded-Proto $scheme;
     proxy_set_header Host $host;
   }
   location /signal {
     proxy_pass http://127.0.0.1:3000;
     proxy_http_version 1.1;
     proxy_set_header Upgrade $http_upgrade;
     proxy_set_header Connection "upgrade";
     proxy_set_header Host $host;
   }
   ```

2. Set `PUBLIC_BASE_URL=https://your-domain.example` and a fixed
   `SIGNAL_SECRET`.

3. Add a **TURN server** (e.g. coturn) in `public/js/webrtc.js`
   (`ICE_SERVERS`) so media works across strict NATs/firewalls.

4. Enable `ENABLE_CSP=true` and `ENABLE_FRAME_DENY=true` once you are not
   embedding the app in a preview iframe.

5. Run behind a process manager (pm2, systemd) — sessions are in-memory, so a
   restart simply invalidates outstanding links/tokens (clients are told the
   session expired and can create a new one).

---

## 🔒 Privacy guarantees (by design)

- `getUserMedia` is called **only** inside the participant's click handler —
  never on page load.
- The host's "Start" button only notifies the participant; it cannot enable
  their camera or mic.
- No `MediaRecorder`, no server-side capture, no storage of media streams.
- Sessions, tickets, and tokens are volatile and expire automatically.

## 🧪 Included smoke test

```bash
NODE_PATH=./node_modules node /tmp/smoke.js   # create → join → signal → end
```

---

Crafted by **Suhan** · MIT License
