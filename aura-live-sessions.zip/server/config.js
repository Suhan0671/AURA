'use strict';

/**
 * Central configuration. Every value can be overridden via environment
 * variables so the same code runs locally and in production unchanged.
 */
const crypto = require('crypto');

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';

module.exports = {
  port,
  host,

  // Public base URL used to build share links (only a fallback when the
  // request host/protocol cannot be trusted, e.g. behind a proxy).
  publicBaseUrl: (process.env.PUBLIC_BASE_URL || '').replace(/\/+$/, ''),

  // HMAC secret used to sign short-lived join tickets. In production set this
  // to a long random string (e.g. `openssl rand -hex 32`) so tickets survive
  // server restarts and cannot be forged.
  signalSecret: process.env.SIGNAL_SECRET || crypto.randomBytes(32).toString('hex'),

  sessions: {
    // Hard lifetime of a session link, regardless of activity.
    maxAgeMs: Number(process.env.SESSION_MAX_AGE_MS || 4 * 60 * 60 * 1000),
    // A session with no activity for this long is auto-expired.
    idleMs: Number(process.env.SESSION_IDLE_MS || 10 * 60 * 1000),
    // This build is a 1:1 session (one creator, one participant at a time).
    maxParticipants: 1,
  },

  tickets: {
    // Join tickets are deliberately short-lived and single-purpose.
    ttlMs: Number(process.env.TICKET_TTL_MS || 60 * 1000),
  },

  rateLimit: {
    windowMs: 60 * 1000,
    globalMax: 300,      // generic API calls / minute / IP
    createMax: 20,       // session creations / minute / IP
    joinMax: 30,         // join attempts / minute / IP
    controlMax: 120,     // control lookups / minute / IP
  },

  ws: {
    maxPayload: 1 << 18,       // 256 KB — ample for SDP + ICE bursts
    maxMessagesPerSec: 40,     // per-socket message rate cap
  },

  // TURN servers should be added here for production (NAT traversal).
  // STUN alone is enough for most same-network / local demos.
  iceServers: [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
  ],

  // Optional hardening flags (kept off by default so the app can be embedded
  // in a development preview; enable in production — see README).
  enableCsp: false,
  enableFrameDeny: false,
};
