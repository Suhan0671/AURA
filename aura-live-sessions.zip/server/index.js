'use strict';

const http = require('http');
const path = require('path');
const express = require('express');
const { WebSocketServer } = require('ws');

const config = require('./config');
const { SessionStore } = require('./sessionStore');
const { Signaling } = require('./signaling');
const { signTicket, safeEqual } = require('./tokens');
const { makeLimiter } = require('./rateLimit');

const app = express();
const server = http.createServer(app);
const publicDir = path.join(__dirname, '..', 'public');

// ---------------------------------------------------------------- middleware
// Honour proxied protocol (https:// behind the preview proxy / nginx / caddy).
app.set('trust proxy', true);

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  // Restrict camera/mic usage to this origin (and its own frames).
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self)');
  if (config.enableFrameDeny) res.setHeader('X-Frame-Options', 'DENY');
  if (config.enableCsp) {
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; " +
      "img-src 'self' data:; media-src 'self' blob:; connect-src 'self' wss: ws:; " +
      "font-src 'self' data:"
    );
  }
  next();
});

app.use(express.json({ limit: '16kb' }));

// ---------------------------------------------------------------- state
const store = new SessionStore(config.sessions);
const globalLimit = makeLimiter({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.globalMax });
const createLimit = makeLimiter({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.createMax });
const joinLimit = makeLimiter({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.joinMax });
const controlLimit = makeLimiter({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.controlMax });

function buildShareUrl(req, id) {
  if (config.publicBaseUrl) return `${config.publicBaseUrl}/s/${id}`;
  const host = req.headers.host || `localhost:${config.port}`;
  const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
  return `${proto}://${host}/s/${id}`;
}

// ---------------------------------------------------------------- REST API
app.use('/api', globalLimit); // blanket cap on all API traffic, per IP

app.get('/api/health', (req, res) => res.json({ ok: true, ts: Date.now() }));

// Create a session (creator).
app.post('/api/sessions', createLimit, (req, res) => {
  const session = store.create();
  res.status(201).json({
    sessionId: session.id,
    controlToken: session.creatorToken,
    shareUrl: buildShareUrl(req, session.id),
    joinPath: `/s/${session.id}`,
    createdAt: session.createdAt,
    expiresAt: store.expiresAt(session),
  });
});

// Participant join: validate the session and issue a short-lived ticket.
app.post('/api/sessions/:id/join', joinLimit, (req, res) => {
  const session = store.get(req.params.id);
  if (!session) {
    return res.status(410).json({
      error: 'expired',
      message: 'This session link has expired or is no longer available.',
    });
  }
  const ticket = signTicket(
    { sessionId: session.id, role: 'participant' },
    config.signalSecret,
    config.tickets.ttlMs
  );
  res.json({ ticket, ttlMs: config.tickets.ttlMs, session: store.snapshot(session) });
});

// Creator re-sync after a refresh (validates the stored control token).
app.post('/api/sessions/:id/control', controlLimit, (req, res) => {
  const session = store.get(req.params.id);
  if (!session) {
    return res.status(410).json({
      error: 'expired',
      message: 'Session expired or does not exist.',
    });
  }
  const token = (req.body && req.body.token) || req.query.token || '';
  if (!safeEqual(token, session.creatorToken)) {
    return res.status(403).json({ error: 'unauthorized', message: 'Invalid control token.' });
  }
  res.json({ session: store.snapshot(session) });
});

// ---------------------------------------------------------------- pages
app.get('/', (req, res) => res.sendFile(path.join(publicDir, 'index.html')));
app.get('/s/:id', (req, res) => res.sendFile(path.join(publicDir, 'join.html')));
app.use(express.static(publicDir, { maxAge: '1h', index: false }));
app.use('/api', (req, res) => res.status(404).json({ error: 'not_found' }));

// ---------------------------------------------------------------- WebSocket
const wss = new WebSocketServer({ noServer: true, maxPayload: config.ws.maxPayload });
const signaling = new Signaling({ wss, store, config });
wss.on('connection', (ws, req) => signaling.handleConnection(ws, req));

server.on('upgrade', (req, socket, head) => {
  let pathname;
  try {
    pathname = new URL(req.url, 'https://localhost').pathname;
  } catch {
    socket.destroy();
    return;
  }
  if (pathname !== '/signal') {
    socket.destroy();
    return;
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});

store.onExpire = (session) => signaling.expire(session);

const heartbeat = setInterval(() => signaling.heartbeat(), 30_000);
if (heartbeat.unref) heartbeat.unref();

server.listen(config.port, config.host, () => {
  console.log('');
  console.log('  ◆ AURA — live camera & microphone sessions');
  console.log(`  ◆ listening on http://${config.host}:${config.port}`);
  console.log(`  ◆ signaling secret: ${config.signalSecret ? '(set)' : '(generated per boot)'}`);
  console.log('');
});

function shutdown() {
  clearInterval(heartbeat);
  store.stop();
  try { wss.close(); } catch { /* ignore */ }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
