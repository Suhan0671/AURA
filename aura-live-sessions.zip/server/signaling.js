'use strict';

/**
 * WebSocket signaling.
 *
 * Security model:
 *   - Every connection MUST authenticate against a live session:
 *       • creator     -> presents the session's creator token (constant-time compare)
 *       • participant -> presents a short-lived HMAC join ticket issued by POST /join
 *   - Invalid/expired sessions are refused at connect and re-checked per message.
 *   - Messages are role-scoped: a participant can never start/end a session and
 *     a creator can never claim to have granted camera access on the
 *     participant's behalf. Media "ready" state originates ONLY from the
 *     participant's own explicit user action.
 *   - Per-socket message rate + size limits guard against flooding.
 */
const { URL } = require('url');
const { verifyTicket, safeEqual, randomId } = require('./tokens');

const CLOSE = {
  EXPIRED: 4001,
  ENDED: 4002,
  UNAUTHORIZED: 4003,
  RATE_LIMITED: 4004,
  ROOM_FULL: 4005,
  REPLACED: 4006,
};

class Signaling {
  constructor({ wss, store, config }) {
    this.wss = wss;
    this.store = store;
    this.config = config;
    this.peers = new Map(); // socket -> { id, role, sessionId, msgTimes: [] }
  }

  handleConnection(ws, req) {
    let url;
    try {
      url = new URL(req.url, 'https://localhost');
    } catch {
      return ws.close(CLOSE.UNAUTHORIZED, 'Bad request');
    }

    const sessionId = (url.searchParams.get('session') || '').slice(0, 128);
    const role = url.searchParams.get('role') || '';
    const token = (url.searchParams.get('token') || '').slice(0, 4096);

    const session = this.store.get(sessionId);
    if (!session) {
      return ws.close(CLOSE.EXPIRED, 'Session expired or does not exist');
    }

    if (role === 'creator') {
      if (!safeEqual(token, session.creatorToken)) {
        return ws.close(CLOSE.UNAUTHORIZED, 'Unauthorized');
      }
    } else if (role === 'participant') {
      const ticket = verifyTicket(token, this.config.signalSecret);
      if (!ticket || ticket.sessionId !== sessionId || ticket.role !== 'participant') {
        return ws.close(CLOSE.UNAUTHORIZED, 'Unauthorized');
      }
    } else {
      return ws.close(CLOSE.UNAUTHORIZED, 'Unauthorized');
    }

    // A newer valid connection for the same role supersedes an older one
    // (handles refreshes / network changes gracefully).
    this._replaceExisting(sessionId, role);

    const peer = { id: randomId(8), role, sessionId, msgTimes: [] };
    this.peers.set(ws, peer);
    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('message', (raw) => this.onMessage(ws, peer, raw));
    ws.on('close', () => this.onClose(ws, peer));
    ws.on('error', () => {});

    this.store.touch(session);
    if (role === 'participant') {
      session.participantConnected = true;
      session.declined = false;
    }

    ws.send(JSON.stringify({ type: 'hello', role, session: this.store.snapshot(session) }));
    this.relay(session, role, { type: 'peer-joined', role });
    this.broadcastState(session);
  }

  _replaceExisting(sessionId, role) {
    for (const [sock, p] of this.peers) {
      if (p.sessionId === sessionId && p.role === role && sock.readyState === 1) {
        sock.close(CLOSE.REPLACED, 'Replaced by a newer connection');
      }
    }
  }

  onMessage(ws, peer, raw) {
    if (raw.length > this.config.ws.maxPayload) {
      return ws.close(CLOSE.RATE_LIMITED, 'Message too large');
    }

    const now = Date.now();
    peer.msgTimes = peer.msgTimes.filter((t) => now - t < 1000);
    if (peer.msgTimes.length >= this.config.ws.maxMessagesPerSec) {
      return ws.close(CLOSE.RATE_LIMITED, 'Message rate exceeded');
    }
    peer.msgTimes.push(now);

    let msg;
    try {
      msg = JSON.parse(raw.toString());
    } catch {
      return;
    }
    if (!msg || typeof msg.type !== 'string') return;

    // Re-validate the session on every message (it may have expired).
    const session = this.store.get(peer.sessionId);
    if (!session) return ws.close(CLOSE.EXPIRED, 'Session expired');
    this.store.touch(session);

    switch (msg.type) {
      case 'ping':
        return ws.send(JSON.stringify({ type: 'pong' }));

      case 'signal':
        if (!msg.data || typeof msg.data !== 'object') return;
        return this.relay(session, peer.role, { type: 'signal', data: msg.data });

      case 'media-ready':
        if (peer.role !== 'participant') return;
        session.media.camera = !!msg.camera;
        session.media.mic = !!msg.mic;
        session.declined = false;
        this.broadcastState(session);
        return this.relay(session, peer.role, {
          type: 'media-ready',
          camera: session.media.camera,
          mic: session.media.mic,
        });

      case 'media-stopped':
        if (peer.role !== 'participant') return;
        session.media.camera = false;
        session.media.mic = false;
        this.broadcastState(session);
        return this.relay(session, peer.role, { type: 'media-stopped' });

      case 'declined':
        if (peer.role !== 'participant') return;
        session.declined = true;
        session.media.camera = false;
        session.media.mic = false;
        this.broadcastState(session);
        return this.relay(session, peer.role, { type: 'declined' });

      case 'start-session':
        if (peer.role !== 'creator') return;
        if (session.phase !== 'live') {
          session.phase = 'live';
          session.startedAt = Date.now();
          this.broadcastState(session);
          this.relay(session, peer.role, { type: 'session-started', startedAt: session.startedAt });
        }
        return;

      case 'stop-session':
        if (peer.role !== 'creator') return;
        if (session.phase === 'live') {
          session.phase = 'idle';
          session.startedAt = null;
          // No longer live → no one is broadcasting.
          session.media.camera = false;
          session.media.mic = false;
          session.declined = false;
          this.broadcastState(session);
          this.relay(session, peer.role, { type: 'session-stopped' });
        }
        return;

      case 'end-session':
        if (peer.role !== 'creator') return;
        return this.endSession(session, 'host');

      default:
        return;
    }
  }

  relay(session, fromRole, payload) {
    const msg = JSON.stringify(payload);
    for (const [sock, p] of this.peers) {
      if (p.sessionId === session.id && p.role !== fromRole && sock.readyState === 1) {
        sock.send(msg);
      }
    }
  }

  broadcastState(session) {
    this.sendToSession(session.id, { type: 'state', session: this.store.snapshot(session) });
  }

  sendToSession(sessionId, payload) {
    const msg = JSON.stringify(payload);
    for (const [sock, p] of this.peers) {
      if (p.sessionId === sessionId && sock.readyState === 1) sock.send(msg);
    }
  }

  endSession(session, reason) {
    this.sendToSession(session.id, { type: 'session-ended', reason });
    for (const [sock, p] of [...this.peers]) {
      if (p.sessionId === session.id) {
        sock.close(CLOSE.ENDED, 'Session ended');
        this.peers.delete(sock);
      }
    }
    this.store.remove(session.id, reason);
  }

  /** Called by the store sweeper when a session is auto-expired. */
  expire(session) {
    this.sendToSession(session.id, { type: 'session-ended', reason: 'expired' });
    for (const [sock, p] of [...this.peers]) {
      if (p.sessionId === session.id) {
        sock.close(CLOSE.EXPIRED, 'Session expired');
        this.peers.delete(sock);
      }
    }
  }

  onClose(ws, peer) {
    this.peers.delete(ws);
    const session = this.store.sessions.get(peer.sessionId);
    if (!session) return;
    if (peer.role === 'participant') {
      session.participantConnected = false;
      session.media.camera = false;
      session.media.mic = false;
      session.declined = false;
      this.store.touch(session);
      this.broadcastState(session);
      this.relay(session, 'participant', { type: 'peer-left', role: 'participant' });
    }
  }

  heartbeat() {
    for (const sock of this.wss.clients) {
      if (sock.isAlive === false) {
        sock.terminate();
        continue;
      }
      sock.isAlive = false;
      try { sock.ping(); } catch { /* ignore */ }
    }
  }
}

module.exports = { Signaling, CLOSE };
