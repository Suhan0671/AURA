'use strict';

/**
 * Cryptographic helpers:
 *  - random session / token IDs (CSPRNG)
 *  - HMAC-signed, expiring "tickets" (used for short-lived participant joins)
 *  - constant-time string comparison (avoid timing side-channels)
 */
const crypto = require('crypto');

function b64url(input) {
  return Buffer.from(input).toString('base64url');
}

/** Sign a JSON payload into an expiring, tamper-evident ticket. */
function signTicket(payload, secret, ttlMs) {
  const exp = Date.now() + ttlMs;
  const body = b64url(JSON.stringify({ ...payload, exp }));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}

/** Verify a ticket; returns the payload or null if invalid/expired. */
function verifyTicket(ticket, secret) {
  if (typeof ticket !== 'string' || ticket.length > 4096) return null;
  const parts = ticket.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expected = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (typeof payload.exp !== 'number' || Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

/** Constant-time string equality. */
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

/** Cryptographically random URL-safe ID of `bytes` entropy. */
function randomId(bytes = 16) {
  return crypto.randomBytes(bytes).toString('base64url');
}

module.exports = { signTicket, verifyTicket, safeEqual, randomId };
