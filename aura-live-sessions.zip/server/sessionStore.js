'use strict';

const { randomId } = require('./tokens');

/**
 * In-memory session store.
 *
 * Sessions are deliberately volatile:
 *   - nothing about the session is persisted to disk
 *   - no media is ever written anywhere
 *   - links expire on a hard max-age OR after a period of inactivity
 */
class SessionStore {
  constructor({ maxAgeMs, idleMs, maxParticipants = 1 } = {}) {
    this.maxAgeMs = maxAgeMs;
    this.idleMs = idleMs;
    this.maxParticipants = maxParticipants;
    this.sessions = new Map();
    this.onExpire = null; // wired up by the signaling layer

    this._sweeper = setInterval(() => this.sweep(), 15_000);
    if (this._sweeper.unref) this._sweeper.unref();
  }

  create() {
    const now = Date.now();
    const session = {
      id: randomId(16),              // 22-char crypto-random session id
      creatorToken: randomId(24),    // creator-only control token
      createdAt: now,
      lastActivityAt: now,
      phase: 'idle',                 // 'idle' | 'live'
      startedAt: null,               // epoch ms when the host went live
      participantConnected: false,
      media: { camera: false, mic: false },
      declined: false,
      ended: false,
      endedReason: null,
    };
    this.sessions.set(session.id, session);
    return session;
  }

  /** Lookup that also enforces expiry. Returns null for unknown/expired. */
  get(id) {
    const s = this.sessions.get(id);
    if (!s) return null;
    if (this.isExpired(s)) {
      this.remove(s.id, 'expired');
      return null;
    }
    return s;
  }

  touch(s) {
    if (s) s.lastActivityAt = Date.now();
  }

  isExpired(s) {
    const now = Date.now();
    return (
      s.ended ||
      now - s.createdAt > this.maxAgeMs ||
      now - s.lastActivityAt > this.idleMs
    );
  }

  expiresAt(s) {
    return Math.min(s.createdAt + this.maxAgeMs, s.lastActivityAt + this.idleMs);
  }

  /** The shape of session data that is safe to expose to clients. */
  snapshot(s) {
    return {
      id: s.id,
      phase: s.phase,
      startedAt: s.startedAt,
      participantConnected: s.participantConnected,
      media: { camera: s.media.camera, mic: s.media.mic },
      declined: s.declined,
      createdAt: s.createdAt,
      lastActivityAt: s.lastActivityAt,
      expiresAt: this.expiresAt(s),
    };
  }

  remove(id, reason = 'ended') {
    const s = this.sessions.get(id);
    if (!s) return;
    s.ended = true;
    s.endedReason = reason;
    this.sessions.delete(id);
  }

  sweep() {
    for (const s of [...this.sessions.values()]) {
      if (this.isExpired(s)) {
        this.remove(s.id, 'expired');
        if (this.onExpire) this.onExpire(s);
      }
    }
  }

  stop() {
    clearInterval(this._sweeper);
  }
}

module.exports = { SessionStore };
