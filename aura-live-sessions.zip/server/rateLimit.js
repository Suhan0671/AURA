'use strict';

/**
 * Minimal dependency-free sliding-window rate limiter, keyed by client IP
 * (honouring X-Forwarded-For when running behind a proxy).
 */
class SlidingWindow {
  constructor({ windowMs, max }) {
    this.windowMs = windowMs;
    this.max = max;
    this.hits = new Map(); // key -> array of timestamps

    this._sweeper = setInterval(() => this.sweep(), windowMs);
    if (this._sweeper.unref) this._sweeper.unref();
  }

  allow(key) {
    const now = Date.now();
    let arr = this.hits.get(key) || [];
    arr = arr.filter((t) => now - t < this.windowMs);
    if (arr.length >= this.max) {
      this.hits.set(key, arr);
      return false;
    }
    arr.push(now);
    this.hits.set(key, arr);
    return true;
  }

  sweep() {
    const now = Date.now();
    for (const [key, arr] of this.hits) {
      const kept = arr.filter((t) => now - t < this.windowMs);
      if (kept.length === 0) this.hits.delete(key);
      else this.hits.set(key, kept);
    }
  }
}

function clientKey(req) {
  const fwd = (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return fwd || req.socket.remoteAddress || 'unknown';
}

function makeLimiter(opts) {
  const limiter = new SlidingWindow(opts);
  return (req, res, next) => {
    if (!limiter.allow(clientKey(req))) {
      return res.status(429).json({
        error: 'rate_limited',
        message: 'Too many requests. Please slow down and try again shortly.',
      });
    }
    next();
  };
}

module.exports = { SlidingWindow, makeLimiter, clientKey };
