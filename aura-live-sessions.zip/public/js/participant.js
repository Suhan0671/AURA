'use strict';

/* ─────────────────────────────────────────────────────────────────────
   AURA · Participant controller
   Consent-first: nothing is accessed until the user clicks "Allow",
   then approves the browser's own permission prompt.
   ───────────────────────────────────────────────────────────────────── */

(function () {
  // ---- state -----------------------------------------------------------
  let sessionId = null;
  let ticket = null;
  let ws = null;
  let pc = null;
  let stream = null;          // local MediaStream (only after explicit consent)
  let live = false;           // host has started the session
  let startedAt = null;
  let sharing = false;        // user currently broadcasting
  let pendingCandidates = [];
  let timerInterval = null;
  let ended = false;

  // ---- DOM ----------------------------------------------------------------
  const $el = {};
  function cacheDom() {
    Object.assign($el, {
      stateConsent: $('#stateConsent'),
      stateGranted: $('#stateGranted'),
      stateDeclined: $('#stateDeclined'),
      stateDenied: $('#stateDenied'),
      stateEnded: $('#stateEnded'),
      btnAllow: $('#btnAllow'),
      btnDecline: $('#btnDecline'),
      btnReconsider: $('#btnReconsider'),
      btnRetry: $('#btnRetry'),
      btnDenyDecline: $('#btnDenyDecline'),
      btnStopShare: $('#btnStopShare'),
      previewVideo: $('#previewVideo'),
      previewVeil: $('#previewVeil'),
      liveBar: $('#liveBar'),
      liveTimer: $('#liveTimer'),
      chipCamera: $('#chipCamera'),
      chipMic: $('#chipMic'),
      grantedNote: $('#grantedNote'),
      consentHostNote: $('#consentHostNote'),
      connLine: $('#connLine'),
      deniedMsg: $('#deniedMsg'),
      endedTitle: $('#endedTitle'),
      endedMsg: $('#endedMsg'),
    });
  }

  function showPanel(name) {
    ['stateConsent', 'stateGranted', 'stateDeclined', 'stateDenied', 'stateEnded'].forEach((k) => {
      $el[k].classList.toggle('hidden', k !== name);
    });
  }

  // ---- boot --------------------------------------------------------------
  async function boot() {
    cacheDom();
    bindUI();

    // parse /s/:id from the path
    const m = location.pathname.match(/^\/s\/([A-Za-z0-9_-]+)\/?$/);
    if (!m) return showEnded('This session link is invalid.', 'Check the link and try again.');
    sessionId = m[1];

    const res = await join();
    if (!res) return; // join() renders the appropriate error state
    connectSignalWs();
  }

  async function join() {
    try {
      const res = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (res.status === 410 || res.status === 404) {
        showEnded('This session has expired.', 'Session links expire automatically after inactivity. Ask the host for a new link.');
        return false;
      }
      if (res.status === 429) {
        showEnded('Too many attempts.', 'Please wait a moment and reload this page.');
        return false;
      }
      if (!res.ok) {
        showEnded('This session is unavailable.', data.message || 'Please ask the host for a new link.');
        return false;
      }
      ticket = data.ticket;
      return true;
    } catch {
      showEnded('Connection problem.', 'We could not reach the server. Check your connection and reload.');
      return false;
    }
  }

  function bindUI() {
    $el.btnAllow.addEventListener('click', allow);
    $el.btnDecline.addEventListener('click', decline);
    $el.btnReconsider.addEventListener('click', () => { showPanel('stateConsent'); setConnState(true); });
    $el.btnRetry.addEventListener('click', allow);
    $el.btnDenyDecline.addEventListener('click', decline);
    $el.btnStopShare.addEventListener('click', stopSharing);

    window.addEventListener('beforeunload', () => {
      if (stream) stopStream(stream);
      if (ws) try { ws.close(1000); } catch { /* ignore */ }
    });
  }

  // ---- signaling -----------------------------------------------------------
  function connectSignalWs() {
    ws = new WebSocket(signalUrl({ sessionId, role: 'participant', token: ticket }));

    ws.onopen = () => setConnState(true);

    ws.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      handleMessage(msg);
    };

    ws.onerror = () => { /* handled via close */ };

    ws.onclose = (e) => {
      if (ended) return;
      if (e.code === 4006) return; // replaced by a newer connection
      if (e.code === 4002) return showEnded('This session has ended.', 'The host closed the session. Nothing was recorded.');
      if (e.code === 4001) return showEnded('This session has expired.', 'Ask the host for a new link.');
      if (e.code === 4003) return showEnded('This link is no longer valid.', 'Ask the host for a new link.');
      if (e.code === 4005) return showEnded('This session already has a participant.', 'Only one participant can join at a time.');
      // transient drop
      setConnState(false);
      stopSharingSilent();
    };
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try { ws.send(JSON.stringify(obj)); } catch { /* ignore */ }
    }
  }

  function handleMessage(msg) {
    switch (msg.type) {
      case 'hello':
      case 'state':
        applyState(msg.session);
        break;
      case 'peer-joined':
        // Host (re)connected → re-offer if we're already sharing.
        if (msg.role === 'creator' && sharing && live && stream) startCall();
        break;
      case 'peer-left':
        if (msg.role === 'creator') {
          setConnState(false);
          $el.grantedNote.textContent = 'Host disconnected — sharing paused.';
          stopSharingSilent();
          showPanel('stateConsent');
          setConnState(false);
        }
        break;
      case 'session-started':
        live = true;
        startedAt = msg.startedAt || Date.now();
        startTimer();
        $el.consentHostNote.textContent = 'The host started the session. Grant access below to go live — you stay in control.';
        if (sharing && stream) {
          setVeil(false);
          $el.grantedNote.textContent = 'Streaming to the host…';
          startCall();
        } else if (sharing) {
          $el.grantedNote.textContent = 'Access granted — the host just went live.';
        }
        break;
      case 'session-stopped':
        live = false;
        startedAt = null;
        stopTimer();
        stopSharingSilent();
        showPanel('stateConsent');
        $el.consentHostNote.textContent = 'The host paused the session. Grant access again when they resume.';
        setConnState(true);
        break;
      case 'signal':
        handleSignal(msg.data);
        break;
      case 'session-ended':
        showEnded(
          msg.reason === 'expired' ? 'This session has expired.' : 'This session has ended.',
          'The host closed the session. Nothing was recorded.'
        );
        break;
      case 'pong':
        break;
    }
  }

  function applyState(s) {
    if (!s) return;
    setConnState(!!s.participantConnected || ws.readyState === WebSocket.OPEN);
    if (s.phase === 'live') {
      if (!live) {
        live = true;
        startedAt = s.startedAt || Date.now();
        startTimer();
        if (sharing && stream) startCall();
      }
    } else if (s.phase !== 'live' && live) {
      live = false;
      startedAt = null;
      stopTimer();
    }
  }

  // ---- consent flow ---------------------------------------------------------
  async function allow() {
    $el.btnAllow.classList.add('loading');
    $el.btnAllow.disabled = true;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user',
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      sharing = true;
      showPanel('stateGranted');
      $el.previewVideo.srcObject = stream;
      playVideo($el.previewVideo, { muted: true });

      // Mark which tracks actually started (some browsers may deliver one but not the other).
      const hasVideo = stream.getVideoTracks().length > 0;
      const hasAudio = stream.getAudioTracks().length > 0;
      $el.chipCamera.classList.toggle('chip-on', hasVideo);
      $el.chipMic.classList.toggle('chip-on', hasAudio);

      send({ type: 'media-ready', camera: hasVideo, mic: hasAudio });

      if (live) {
        setVeil(false);
        $el.grantedNote.textContent = 'Streaming to the host…';
        await startCall();
      } else {
        setVeil(true, 'Access granted — waiting for the host to start…');
        $el.grantedNote.textContent = 'Access granted — waiting for the host to start the session.';
      }
    } catch (err) {
      sharing = false;
      stream = null;
      showDenied(err);
    } finally {
      $el.btnAllow.classList.remove('loading');
      $el.btnAllow.disabled = false;
    }
  }

  function showDenied(err) {
    $el.deniedMsg.textContent = mediaErrorMessage(err);
    showPanel('stateDenied');
    send({ type: 'declined' });
  }

  function decline() {
    send({ type: 'declined' });
    showPanel('stateDeclined');
  }

  function stopSharing() {
    stopSharingSilent();
    send({ type: 'media-stopped' });
    showPanel('stateConsent');
    setConnState(true);
    $el.consentHostNote.textContent = 'You stopped sharing. Grant access again if you want to resume.';
  }

  /** Stop all local media without changing the consent UI. */
  function stopSharingSilent() {
    closePeer(pc);
    pc = null;
    pendingCandidates = [];
    if (stream) stopStream(stream);
    stream = null;
    sharing = false;
    $el.previewVideo.srcObject = null;
  }

  /** Toggle the "you are live" veil over the local preview. */
  function setVeil(visible, text) {
    if (visible) {
      $el.previewVeil.style.opacity = '1';
      $el.previewVeil.querySelector('p').textContent = text || 'You are live.';
    } else {
      $el.previewVeil.style.opacity = '0';
    }
  }

  // ---- WebRTC (participant is the initiator) --------------------------------
  function ensurePeer() {
    if (pc) return pc;
    pc = createPeer({
      onCandidate: (candidate) => send({ type: 'signal', data: { type: 'ice', candidate } }),
      onConnectionChange: (state) => {
        if (state === 'failed') restartIce();
      },
    });
    return pc;
  }

  async function startCall() {
    if (!stream) return;
    try {
      closePeer(pc);
      pendingCandidates = [];
      pc = ensurePeer();
      const offer = await createOffer(pc, stream);
      send({ type: 'signal', data: { type: 'offer', sdp: offer } });
    } catch (err) {
      console.error('startCall failed', err);
      toast('Could not start the live stream', 'error');
    }
  }

  async function restartIce() {
    try {
      const offer = await createOffer(pc, null, { iceRestart: true });
      send({ type: 'signal', data: { type: 'offer', sdp: offer } });
    } catch { /* ignore */ }
  }

  function handleSignal(data) {
    if (!data || typeof data !== 'object') return;
    if (data.type === 'answer') return handleAnswer(data);
    if (data.type === 'ice' && data.candidate) return handleIce(data.candidate);
  }

  async function handleAnswer(data) {
    try {
      if (!pc) return;
      await pc.setRemoteDescription(data.sdp);
      flushCandidates();
    } catch (err) {
      console.error('handleAnswer failed', err);
    }
  }

  async function handleIce(candidate) {
    try {
      if (!pc || !pc.remoteDescription) {
        pendingCandidates.push(candidate);
        return;
      }
      await pc.addIceCandidate(candidate);
    } catch { /* ignore */ }
  }

  function flushCandidates() {
    if (!pc) return;
    const queue = pendingCandidates;
    pendingCandidates = [];
    for (const c of queue) {
      pc.addIceCandidate(c).catch(() => {});
    }
  }

  // ---- session end -----------------------------------------------------------
  function showEnded(title, message) {
    ended = true;
    stopSharingSilent();
    stopTimer();
    if (ws) { try { ws.close(1000); } catch { /* ignore */ } }
    $el.endedTitle.textContent = title;
    $el.endedMsg.textContent = message;
    showPanel('stateEnded');
  }

  function setConnState(connected) {
    if (!connected) {
      $el.connLine.classList.remove('connected');
      $el.connLine.innerHTML = '<span class="dot"></span>Reconnecting…';
      return;
    }
    $el.connLine.classList.add('connected');
    $el.connLine.innerHTML = '<span class="dot"></span>Connected to host';
  }

  // ---- timer -------------------------------------------------------------------
  function startTimer() {
    stopTimer();
    const paint = () => {
      if (!startedAt) return;
      $el.liveTimer.textContent = fmtClock(Date.now() - startedAt);
    };
    paint();
    timerInterval = setInterval(paint, 1000);
  }
  function stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    $el.liveTimer.textContent = '00:00';
  }

  boot();
})();
