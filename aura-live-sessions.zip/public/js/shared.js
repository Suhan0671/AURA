'use strict';

/* ─────────────────────────────────────────────────────────────────────
   AURA · shared client utilities
   ───────────────────────────────────────────────────────────────────── */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function el(tag, cls, html) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (html != null) n.innerHTML = html;
  return n;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

/** mm:ss (or hh:mm:ss) clock from milliseconds. */
function fmtClock(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(sec)}` : `${pad(m)}:${pad(sec)}`;
}

/** Human "in 4m 12s" style expiry label. */
function fmtCountdown(ts) {
  const diff = ts - Date.now();
  if (diff <= 0) return 'expired';
  const s = Math.floor(diff / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h > 0) return `in ${h}h ${m % 60}m`;
  if (m > 0) return `in ${m}m ${s % 60}s`;
  return `in ${s}s`;
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

function signalUrl({ sessionId, role, token }) {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  return `${proto}://${location.host}/signal?session=${encodeURIComponent(sessionId)}&role=${role}&token=${encodeURIComponent(token)}`;
}

/* ── toasts ─────────────────────────────────────────────────────────── */
function toast(message, kind = 'info', ms = 3200) {
  const box = $('#toasts') || (() => {
    const b = el('div'); b.id = 'toasts';
    document.body.appendChild(b);
    return b;
  })();
  const t = el('div', `toast toast-${kind}`);
  t.innerHTML = `<span class="toast-dot"></span><span class="toast-msg">${escapeHtml(message)}</span>`;
  box.appendChild(t);
  requestAnimationFrame(() => t.classList.add('show'));
  setTimeout(() => {
    t.classList.remove('show');
    t.classList.add('hide');
    setTimeout(() => t.remove(), 400);
  }, ms);
}

/* ── getUserMedia error → friendly copy ─────────────────────────────── */
function mediaErrorMessage(err) {
  const name = (err && err.name) || '';
  switch (name) {
    case 'NotAllowedError':
    case 'SecurityError':
      return 'Permission was denied. Camera and microphone access is required to join this session. You can allow access from your browser’s site settings and try again.';
    case 'NotFoundError':
    case 'DevicesNotFoundError':
      return 'No camera or microphone was found on this device. Connect one and try again.';
    case 'NotReadableError':
    case 'TrackStartError':
      return 'Your camera or microphone is busy in another application. Close other apps using them and try again.';
    case 'OverconstrainedError':
      return 'Your camera does not support the requested settings. Try a different camera.';
    default:
      return 'We could not access your camera or microphone. Please check your device and browser permissions, then try again.';
  }
}

/* ── WebSocket helper with auto-reconnect ───────────────────────────── */
function connectSignal({ sessionId, role, token, onMessage, onOpen, onClose, onError }) {
  const ws = new WebSocket(signalUrl({ sessionId, role, token }));
  let closedByUs = false;

  ws.onopen = () => { if (onOpen) onOpen(ws); };
  ws.onmessage = (e) => {
    let msg;
    try { msg = JSON.parse(e.data); } catch { return; }
    if (onMessage) onMessage(msg);
  };
  ws.onerror = () => { if (onError) onError(); };
  ws.onclose = (e) => {
    if (onClose) onClose(e.code, e.reason);
  };

  ws._destroy = () => { closedByUs = true; try { ws.close(1000); } catch { /* noop */ } };
  return ws;
}
