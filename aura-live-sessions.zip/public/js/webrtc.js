'use strict';

/* ─────────────────────────────────────────────────────────────────────
   AURA · WebRTC helpers (shared by creator & participant)
   ───────────────────────────────────────────────────────────────────── */

// Public STUN servers. Add TURN credentials here in production.
const ICE_SERVERS = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
];

function createPeer({ onTrack, onCandidate, onConnectionChange }) {
  const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

  pc.onicecandidate = (e) => {
    if (e.candidate && onCandidate) onCandidate(e.candidate);
  };
  pc.ontrack = (e) => {
    if (e.streams && e.streams[0] && onTrack) onTrack(e.streams[0]);
  };
  pc.onconnectionstatechange = () => {
    if (onConnectionChange) onConnectionChange(pc.connectionState);
  };
  pc.oniceconnectionstatechange = () => {
    // Surface ICE-level failures too (network changes, TURN absence).
    if (pc.iceConnectionState === 'failed' && onConnectionChange) onConnectionChange('failed');
  };
  return pc;
}

/** Create + set a local offer (optionally with ICE restart). */
async function createOffer(pc, stream, opts = {}) {
  if (stream) {
    stream.getTracks().forEach((t) => pc.addTrack(t, stream));
  }
  const offer = await pc.createOffer(opts);
  await pc.setLocalDescription(offer);
  return pc.localDescription;
}

function closePeer(pc) {
  if (!pc) return null;
  try {
    pc.onicecandidate = null;
    pc.ontrack = null;
    pc.onconnectionstatechange = null;
    pc.oniceconnectionstatechange = null;
    pc.close();
  } catch { /* ignore */ }
  return null;
}

function stopStream(stream) {
  if (stream) {
    stream.getTracks().forEach((t) => { try { t.stop(); } catch { /* ignore */ } });
  }
  return null;
}

/**
 * Lightweight mic activity meter via WebAudio. Returns { stop } to tear down.
 * onLevel receives an RMS value roughly in 0..1.
 */
function attachMicMeter(stream, onLevel) {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const ctx = new AC();
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 512;
    analyser.smoothingTimeConstant = 0.6;
    src.connect(analyser);
    const data = new Uint8Array(analyser.frequencyBinCount);
    let raf = 0;
    const loop = () => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) {
        const v = (data[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / data.length);
      if (onLevel) onLevel(rms);
      raf = requestAnimationFrame(loop);
    };
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    loop();
    return {
      ctx,
      stop: () => {
        cancelAnimationFrame(raf);
        try { src.disconnect(); } catch { /* ignore */ }
        try { ctx.close(); } catch { /* ignore */ }
      },
    };
  } catch {
    return null;
  }
}

/** Play a video element (autoplay policies); returns a Promise<boolean>. */
async function playVideo(video, { muted = false } = {}) {
  video.muted = muted;
  video.autoplay = true;
  try {
    await video.play();
    return true;
  } catch {
    return false;
  }
}
