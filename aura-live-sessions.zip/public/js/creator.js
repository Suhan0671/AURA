'use strict';

/* ─────────────────────────────────────────────────────────────────────
   AURA · Creator (host) controller
   ───────────────────────────────────────────────────────────────────── */

(function () {
  const STORE_KEY = 'aura.session.v1';

  // ---- state ---------------------------------------------------------
  let session = null;        // { id, token }
  let ws = null;
  let pc = null;
  let remoteStream = null;
  let meter = null;
  let timerInterval = null;
  let reconnectTimer = null;
  let reconnectAttempts = 0;
  let ended = false;

  let live = false;              // is the session phase 'live'?
  let startedAt = null;          // epoch ms
  let audioMuted = false;        // remote audio not yet playing

  // ---- DOM ------------------------------------------------------------
  const $el = {};
  function cacheDom() {
    Object.assign($el, {
      homeView: $('#homeView'),
      sessionView: $('#sessionView'),
      createBtn: $('#createBtn'),
      topStatus: $('#topStatus'),
      topStatusText: $('#topStatusText'),
      remoteVideo: $('#remoteVideo'),
      stagePlaceholder: $('#stagePlaceholder'),
      stagePlaceholderText: $('#stagePlaceholderText'),
      stagePlaceholderHint: $('#stagePlaceholderHint'),
      stageLivePill: $('#stageLivePill'),
      badgeCamera: $('#badgeCamera'),
      badgeMic: $('#badgeMic'),
      micMeter: $('#micMeter'),
      unmuteBtn: $('#unmuteBtn'),
      connNote: $('#connNote'),
      timer: $('#timer'),
      shareLink: $('#shareLink'),
      copyBtn: $('#copyBtn'),
      openLinkBtn: $('#openLinkBtn'),
      expiryNote: $('#expiryNote'),
      rowParticipant: $('#rowParticipant'),
      rowParticipantText: $('#rowParticipantText'),
      rowCamera: $('#rowCamera'),
      rowCameraText: $('#rowCameraText'),
      rowMic: $('#rowMic'),
      rowMicText: $('#rowMicText'),
      declinedNote: $('#declinedNote'),
      btnStart: $('#btnStart'),
      btnStop: $('#btnStop'),
      btnEnd: $('#btnEnd'),
    });
  }

  // ---- boot ------------------------------------------------------------
  async function boot() {
    cacheDom();
    bindUI();
    const saved = loadSaved();
    if (saved) {
      const ok = await resume(saved);
      if (!ok) showHome();
    } else {
      showHome();
    }
  }

  function loadSaved() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (data && data.id && data.token) return data;
    } catch { /* ignore */ }
    return null;
  }

  function saveSession() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(session)); } catch { /* ignore */ }
  }
  function clearSaved() {
    try { localStorage.removeItem(STORE_KEY); } catch { /* ignore */ }
  }

  // ---- UI wiring --------------------------------------------------------
  function bindUI() {
    $el.createBtn.addEventListener('click', createSession);
    $el.copyBtn.addEventListener('click', copyLink);
    $el.openLinkBtn.addEventListener('click', () => {
      if (session) window.open($el.shareLink.value, '_blank', 'noopener');
    });
    $el.btnStart.addEventListener('click', startSession);
    $el.btnStop.addEventListener('click', stopSession);
    $el.btnEnd.addEventListener('click', endSession);
    $el.unmuteBtn.addEventListener('click', () => playRemoteAudio(true));

    window.addEventListener('beforeunload', () => {
      if (remoteStream) stopStream(remoteStream);
      if (meter) meter.stop();
      if (ws) try { ws.close(1000); } catch { /* ignore */ }
    });
  }

  // ---- view switching -----------------------------------------------------
  function showHome() {
    $el.homeView.classList.remove('hidden');
    $el.sessionView.classList.add('hidden');
    setTopStatus('off', 'Offline');
  }

  function showSession() {
    $el.homeView.classList.add('hidden');
    $el.sessionView.classList.remove('hidden');
  }

  // ---- REST ---------------------------------------------------------------
  async function createSession() {
    $el.createBtn.classList.add('loading');
    $el.createBtn.disabled = true;
    try {
      const res = await fetch('/api/sessions', { method: 'POST', headers: { 'Content-Type': 'application/json' } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Could not create session');
      session = { id: data.sessionId, token: data.controlToken };
      saveSession();
      enterSession(data);
    } catch (err) {
      toast(err.message || 'Could not create session', 'error');
    } finally {
      $el.createBtn.classList.remove('loading');
      $el.createBtn.disabled = false;
    }
  }

  async function resume(saved) {
    try {
      const res = await fetch(`/api/sessions/${encodeURIComponent(saved.id)}/control`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: saved.token }),
      });
      if (res.status === 410 || res.status === 403) {
        clearSaved();
        return false;
      }
      if (!res.ok) return false;
      const data = await res.json();
      session = saved;
      enterSession({ shareUrl: buildShareUrl(saved.id) });
      return true;
    } catch {
      return false;
    }
  }

  function buildShareUrl(id) {
    return `${location.origin}/s/${id}`;
  }

  function enterSession(meta) {
    ended = false;
    showSession();
    $el.shareLink.value = meta.shareUrl || buildShareUrl(session.id);
    if (meta.expiresAt) updateExpiry(meta.expiresAt);
    resetStage();
    connectSignalWs();
  }

  function updateExpiry(ts) {
    const tick = () => {
      const label = fmtCountdown(ts);
      $el.expiryNote.textContent = label === 'expired' ? 'Expiring soon…' : `Link expires ${label}`;
    };
    tick();
    const iv = setInterval(() => {
      if (!session) return clearInterval(iv);
      tick();
    }, 30000);
  }

  // ---- signaling -----------------------------------------------------------
  function connectSignalWs() {
    if (ended || !session) return;
    clearTimeout(reconnectTimer);

    ws = new WebSocket(signalUrl({ sessionId: session.id, role: 'creator', token: session.token }));

    ws.onopen = () => {
      reconnectAttempts = 0;
      setTopStatus('wait', 'Connected · signaling');
    };

    ws.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      handleMessage(msg);
    };

    ws.onerror = () => { /* handled via onclose */ };

    ws.onclose = (e) => {
      if (ended) return;
      if (e.code === 4006) return;              // replaced by a newer tab
      if (e.code === 4002) return onSessionEnded('host');
      if (e.code === 4001) return onSessionExpired();
      if (e.code === 4003) return onSessionEnded('unauthorized');

      // transient drop → reconnect with backoff
      setTopStatus('wait', 'Reconnecting…');
      reconnectAttempts += 1;
      const delay = Math.min(1000 * Math.pow(1.7, reconnectAttempts), 12000);
      reconnectTimer = setTimeout(connectSignalWs, delay);
    };
  }

  function send(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try { ws.send(JSON.stringify(obj)); } catch { /* ignore */ }
    }
  }

  function handleMessage(msg) {
    switch (msg.type) {
      case 'hello':
      case 'state':
        applyState(msg.session);
        break;
      case 'peer-joined':
        if (msg.role === 'participant') toast('Participant joined', 'success');
        break;
      case 'peer-left':
        if (msg.role === 'participant') {
          toast('Participant disconnected', 'warn');
          clearMedia();
          setPlaceholder('Waiting for participant…', 'Share the invite link to get started');
        }
        break;
      case 'session-started':
        live = true;
        startedAt = msg.startedAt || Date.now();
        startTimer();
        $el.stageLivePill.classList.add('is-live');
        $el.stageLivePill.querySelector('span:last-child').textContent = 'LIVE';
        toggleControls(true);
        setTopStatus('on', 'Live');
        toast('Session is live', 'success');
        break;
      case 'session-stopped':
        live = false;
        startedAt = null;
        stopTimer();
        $el.stageLivePill.classList.remove('is-live');
        $el.stageLivePill.querySelector('span:last-child').textContent = 'STANDBY';
        toggleControls(false);
        clearMedia();
        setTopStatus('wait', 'Standby');
        toast('Session paused', 'info');
        break;
      case 'media-ready':
        applyMedia(true, msg.camera, msg.mic);
        break;
      case 'media-stopped':
        applyMedia(false, false, false);
        break;
      case 'declined':
        $el.declinedNote.classList.remove('hidden');
        break;
      case 'signal':
        handleSignal(msg.data);
        break;
      case 'session-ended':
        onSessionEnded(msg.reason);
        break;
      case 'pong':
        break;
    }
  }

  function applyState(s) {
    if (!s) return;
    // participant presence
    const present = !!s.participantConnected;
    setStatusRow($el.rowParticipant, $el.rowParticipantText,
      present ? 'Connected' : 'Waiting to join',
      present ? 'on' : 'off',
      present ? 'good' : '');

    // media
    applyMedia(present, s.media && s.media.camera, s.media && s.media.mic);

    // declined
    $el.declinedNote.classList.toggle('hidden', !s.declined);

    // phase
    if (s.phase === 'live' && !live) {
      live = true;
      startedAt = s.startedAt || Date.now();
      startTimer();
      $el.stageLivePill.classList.add('is-live');
      $el.stageLivePill.querySelector('span:last-child').textContent = 'LIVE';
      toggleControls(true);
      setTopStatus('on', 'Live');
    } else if (s.phase !== 'live' && live) {
      live = false;
      startedAt = null;
      stopTimer();
      $el.stageLivePill.classList.remove('is-live');
      $el.stageLivePill.querySelector('span:last-child').textContent = 'STANDBY';
      toggleControls(false);
      setTopStatus('wait', 'Standby');
    }

    // placeholder copy
    if (!present) {
      if (!remoteStream) setPlaceholder('Waiting for participant…', 'Share the invite link to get started');
    } else if (!s.media.camera && !s.media.mic) {
      if (!remoteStream) setPlaceholder('Participant connected', 'Waiting for them to grant camera & microphone access');
    }
  }

  function applyMedia(present, cam, mic) {
    $el.badgeCamera.classList.toggle('hidden', !cam);
    $el.badgeMic.classList.toggle('hidden', !mic);
    setStatusRow($el.rowCamera, $el.rowCameraText, cam ? 'Connected' : 'Not connected', cam ? 'on' : 'off', cam ? 'good' : '');
    setStatusRow($el.rowMic, $el.rowMicText, mic ? 'Connected' : 'Not connected', mic ? 'on' : 'off', mic ? 'good' : '');
    if (!cam && !mic) {
      if (meter) { meter.stop(); meter = null; }
      $$('#micMeter i').forEach((b) => b.classList.remove('on'));
    }
  }

  function setStatusRow(row, valueEl, text, dotState, valueClass) {
    const dot = row.querySelector('.sr-dot');
    dot.className = 'sr-dot ' + (dotState === 'on' ? 'is-on' : dotState === 'warn' ? 'is-warn' : 'is-off');
    valueEl.textContent = text;
    valueEl.className = 'sr-value ' + (valueClass || '');
    row.classList.toggle('lit', dotState === 'on');
  }

  function setPlaceholder(main, hint) {
    $el.stagePlaceholderText.textContent = main;
    $el.stagePlaceholderHint.textContent = hint;
    $el.stagePlaceholder.classList.remove('hidden');
  }

  function clearMedia() {
    closePeer(pc);
    pc = null;
    if (remoteStream) stopStream(remoteStream);
    remoteStream = null;
    $el.remoteVideo.srcObject = null;
    $el.unmuteBtn.classList.add('hidden');
    audioMuted = false;
    setConnNote('');
    $el.stagePlaceholder.classList.remove('hidden');
  }

  // ---- controls -----------------------------------------------------------
  function startSession() {
    $el.btnStart.classList.add('loading');
    $el.btnStart.disabled = true;
    send({ type: 'start-session' });
    setTimeout(() => {
      $el.btnStart.classList.remove('loading');
      $el.btnStart.disabled = false;
    }, 600);
  }

  function stopSession() {
    send({ type: 'stop-session' });
  }

  function endSession() {
    if (!session) return;
    send({ type: 'end-session' });
    onSessionEnded('host');
  }

  function toggleControls(isLive) {
    $el.btnStart.classList.toggle('hidden', isLive);
    $el.btnStop.classList.toggle('hidden', !isLive);
  }

  function onSessionEnded(reason) {
    if (ended) return;
    ended = true;
    clearTimeout(reconnectTimer);
    clearMedia();
    stopTimer();
    if (ws) { try { ws.close(1000); } catch { /* ignore */ } }
    ws = null;
    session = null;
    clearSaved();
    setTopStatus('off', 'Offline');
    showHome();
    if (reason === 'expired') toast('Session expired', 'warn');
    else toast('Session ended', 'info');
  }

  function onSessionExpired() {
    if (ended) return;
    ended = true;
    clearMedia();
    stopTimer();
    session = null;
    clearSaved();
    setTopStatus('off', 'Offline');
    showHome();
    toast('Session link expired', 'warn');
  }

  // ---- timer --------------------------------------------------------------
  function startTimer() {
    stopTimer();
    const paint = () => {
      if (!startedAt) return;
      $el.timer.textContent = fmtClock(Date.now() - startedAt);
    };
    paint();
    $el.timer.classList.add('running');
    timerInterval = setInterval(paint, 1000);
  }
  function stopTimer() {
    clearInterval(timerInterval);
    timerInterval = null;
    $el.timer.textContent = '00:00';
    $el.timer.classList.remove('running');
  }

  // ---- WebRTC (creator is the answerer / receiver) ------------------------
  let pendingCandidates = [];

  function ensurePeer() {
    if (pc) return pc;
    pc = createPeer({
      onTrack: (stream) => attachRemote(stream),
      onCandidate: (candidate) => send({ type: 'signal', data: { type: 'ice', candidate } }),
      onConnectionChange: (state) => {
        if (state === 'connected') setConnNote('Peer-to-peer connected');
        else if (state === 'connecting') setConnNote('Establishing peer connection…');
        else if (state === 'disconnected') setConnNote('Connection interrupted');
        else if (state === 'failed') setConnNote('Connection lost — waiting for participant…');
      },
    });
    return pc;
  }

  function handleSignal(data) {
    if (!data || typeof data !== 'object') return;
    if (data.type === 'offer') return handleOffer(data);
    if (data.type === 'ice' && data.candidate) return handleIce(data.candidate);
    // 'answer' is not expected on the creator side
  }

  async function handleOffer(data) {
    try {
      closePeer(pc);
      pendingCandidates = [];
      pc = ensurePeer();
      await pc.setRemoteDescription(data.sdp);
      flushCandidates();
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      send({ type: 'signal', data: { type: 'answer', sdp: pc.localDescription } });
    } catch (err) {
      console.error('handleOffer failed', err);
      toast('Could not establish media connection', 'error');
    }
  }

  async function handleIce(candidate) {
    try {
      if (!pc || !pc.remoteDescription) {
        pendingCandidates.push(candidate);
        return;
      }
      await pc.addIceCandidate(candidate);
    } catch { /* ignore */ }
  }

  function flushCandidates() {
    if (!pc) return;
    const queue = pendingCandidates;
    pendingCandidates = [];
    for (const c of queue) {
      pc.addIceCandidate(c).catch(() => {});
    }
  }

  function attachRemote(stream) {
    remoteStream = stream;
    $el.remoteVideo.srcObject = stream;
    $el.stagePlaceholder.classList.add('hidden');
    playRemoteAudio(false).then((ok) => {
      if (!ok) {
        audioMuted = true;
        $el.unmuteBtn.classList.remove('hidden');
      }
    });
    if (meter) meter.stop();
    meter = attachMicMeter(stream, (level) => paintMeter(level));
  }

  function paintMeter(level) {
    const bars = $$('#micMeter i');
    const active = Math.round(Math.min(1, level * 3.4) * bars.length);
    bars.forEach((b, i) => b.classList.toggle('on', i < active));
  }

  async function playRemoteAudio(force) {
    const video = $el.remoteVideo;
    if (force) {
      audioMuted = false;
      $el.unmuteBtn.classList.add('hidden');
    }
    const ok = await playVideo(video, { muted: false });
    if (ok) {
      audioMuted = false;
      $el.unmuteBtn.classList.add('hidden');
    }
    return ok;
  }

  function setConnNote(text) {
    $el.connNote.textContent = text;
    $el.connNote.style.display = text ? '' : 'none';
  }

  function resetStage() {
    $el.stageLivePill.classList.remove('is-live');
    $el.stageLivePill.querySelector('span:last-child').textContent = 'STANDBY';
    $el.badgeCamera.classList.add('hidden');
    $el.badgeMic.classList.add('hidden');
    $el.declinedNote.classList.add('hidden');
    $$('#micMeter i').forEach((b) => b.classList.remove('on'));
    setStatusRow($el.rowParticipant, $el.rowParticipantText, 'Waiting to join', 'off', '');
    setStatusRow($el.rowCamera, $el.rowCameraText, 'Not connected', 'off', '');
    setStatusRow($el.rowMic, $el.rowMicText, 'Not connected', 'off', '');
    setPlaceholder('Waiting for participant…', 'Share the invite link to get started');
    toggleControls(false);
    stopTimer();
    setTopStatus('wait', 'Signaling…');
  }

  function copyLink() {
    copyText($el.shareLink.value).then((ok) => {
      toast(ok ? 'Invite link copied' : 'Could not copy — select and copy manually', ok ? 'success' : 'warn');
    });
  }

  function setTopStatus(state, text) {
    $el.topStatus.className = 'status-pill ' +
      (state === 'on' ? 'is-on' : state === 'wait' ? 'is-wait' : 'is-off');
    $el.topStatusText.textContent = text;
  }

  boot();
})();
